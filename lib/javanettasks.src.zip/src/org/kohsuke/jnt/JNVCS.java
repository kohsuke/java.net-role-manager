package org.kohsuke.jnt;

/**
 * Version control systems.
 * 
 * @author Kohsuke Kawaguchi
 */
public enum JNVCS {
    CVS, SVN;
}
