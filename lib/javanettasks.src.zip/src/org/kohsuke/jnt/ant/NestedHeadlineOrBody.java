/*
 * $Id: NestedHeadlineOrBody.java,v 1.1 2003/12/17 05:40:20 ryan_shoemaker Exp $
 *  
 */
package org.kohsuke.jnt.ant;

/**
 * This class handles nested headline and body elements of the NewsItemTask.
 * 
 * @author Ryan Shoemaker
 * @version $Revision: 1.1 $
 */
public class NestedHeadlineOrBody {

    private String content;

    public NestedHeadlineOrBody() {
    }

    public void addText(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }
}
